Decimal128 is a porting of Arrow Decimal128 C++ to pure C library.
